﻿namespace Projet1.Admin
{
    partial class Rapport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.infoClientInviteDataGridView = new System.Windows.Forms.DataGridView();
            this.infoSoinPersonneDataGridView = new System.Windows.Forms.DataGridView();
            this.infoSoinPersonneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.chambreDataGridView = new System.Windows.Forms.DataGridView();
            this.infoChambreDataGridView = new System.Windows.Forms.DataGridView();
            this.infoChambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.nbSoin = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.assistantNameDataGridView = new System.Windows.Forms.DataGridView();
            this.infoSoinAssistantDataGridView = new System.Windows.Forms.DataGridView();
            this.infoSoinAssistantBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rapportPersonneDataGridView = new System.Windows.Forms.DataGridView();
            this.rapportPersonneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nbMontant = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.assistantNameBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.b56Projet1Equipe7DataSet = new Projet1.B56Projet1Equipe7DataSet();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chambreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.infoClientInviteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.infoClientInviteTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.InfoClientInviteTableAdapter();
            this.tableAdapterManager = new Projet1.B56Projet1Equipe7DataSetTableAdapters.TableAdapterManager();
            this.infoSoinPersonneTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.InfoSoinPersonneTableAdapter();
            this.chambreTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.chambreTableAdapter();
            this.infoChambreTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.InfoChambreTableAdapter();
            this.assistantNameTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.AssistantNameTableAdapter();
            this.infoSoinAssistantTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.InfoSoinAssistantTableAdapter();
            this.rapportPersonneTableAdapter = new Projet1.B56Projet1Equipe7DataSetTableAdapters.RapportPersonneTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.infoClientInviteDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinPersonneDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinPersonneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoChambreDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoChambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantNameDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinAssistantDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinAssistantBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportPersonneDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportPersonneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantNameBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.b56Projet1Equipe7DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoClientInviteBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Visualisation des rapports";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(474, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Rapport des soins offerts aux clients et aux invités";
            // 
            // infoClientInviteDataGridView
            // 
            this.infoClientInviteDataGridView.AllowUserToAddRows = false;
            this.infoClientInviteDataGridView.AllowUserToDeleteRows = false;
            this.infoClientInviteDataGridView.AllowUserToResizeColumns = false;
            this.infoClientInviteDataGridView.AllowUserToResizeRows = false;
            this.infoClientInviteDataGridView.AutoGenerateColumns = false;
            this.infoClientInviteDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.infoClientInviteDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.infoClientInviteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.infoClientInviteDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.infoClientInviteDataGridView.DataSource = this.infoClientInviteBindingSource;
            this.infoClientInviteDataGridView.Location = new System.Drawing.Point(17, 93);
            this.infoClientInviteDataGridView.Name = "infoClientInviteDataGridView";
            this.infoClientInviteDataGridView.ReadOnly = true;
            this.infoClientInviteDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.infoClientInviteDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.infoClientInviteDataGridView.Size = new System.Drawing.Size(243, 220);
            this.infoClientInviteDataGridView.TabIndex = 3;
            // 
            // infoSoinPersonneDataGridView
            // 
            this.infoSoinPersonneDataGridView.AllowUserToAddRows = false;
            this.infoSoinPersonneDataGridView.AllowUserToDeleteRows = false;
            this.infoSoinPersonneDataGridView.AllowUserToResizeColumns = false;
            this.infoSoinPersonneDataGridView.AllowUserToResizeRows = false;
            this.infoSoinPersonneDataGridView.AutoGenerateColumns = false;
            this.infoSoinPersonneDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.infoSoinPersonneDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.infoSoinPersonneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.infoSoinPersonneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.prix,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.infoSoinPersonneDataGridView.DataSource = this.infoSoinPersonneBindingSource;
            this.infoSoinPersonneDataGridView.Location = new System.Drawing.Point(291, 93);
            this.infoSoinPersonneDataGridView.Name = "infoSoinPersonneDataGridView";
            this.infoSoinPersonneDataGridView.ReadOnly = true;
            this.infoSoinPersonneDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.infoSoinPersonneDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.infoSoinPersonneDataGridView.Size = new System.Drawing.Size(537, 220);
            this.infoSoinPersonneDataGridView.TabIndex = 4;
            // 
            // infoSoinPersonneBindingSource
            // 
            this.infoSoinPersonneBindingSource.DataMember = "InfoClientInvite_InfoSoinPersonne";
            this.infoSoinPersonneBindingSource.DataSource = this.infoClientInviteBindingSource;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 346);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(370, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "Rapport des réservations de chambres";
            // 
            // chambreDataGridView
            // 
            this.chambreDataGridView.AllowUserToAddRows = false;
            this.chambreDataGridView.AllowUserToDeleteRows = false;
            this.chambreDataGridView.AllowUserToResizeColumns = false;
            this.chambreDataGridView.AllowUserToResizeRows = false;
            this.chambreDataGridView.AutoGenerateColumns = false;
            this.chambreDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.chambreDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.chambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.chambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.chambreDataGridView.DataSource = this.chambreBindingSource;
            this.chambreDataGridView.Location = new System.Drawing.Point(17, 373);
            this.chambreDataGridView.Name = "chambreDataGridView";
            this.chambreDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.chambreDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.chambreDataGridView.Size = new System.Drawing.Size(243, 220);
            this.chambreDataGridView.TabIndex = 5;
            // 
            // infoChambreDataGridView
            // 
            this.infoChambreDataGridView.AllowUserToAddRows = false;
            this.infoChambreDataGridView.AllowUserToDeleteRows = false;
            this.infoChambreDataGridView.AllowUserToResizeColumns = false;
            this.infoChambreDataGridView.AllowUserToResizeRows = false;
            this.infoChambreDataGridView.AutoGenerateColumns = false;
            this.infoChambreDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.infoChambreDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.infoChambreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.infoChambreDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16});
            this.infoChambreDataGridView.DataSource = this.infoChambreBindingSource;
            this.infoChambreDataGridView.Location = new System.Drawing.Point(291, 373);
            this.infoChambreDataGridView.Name = "infoChambreDataGridView";
            this.infoChambreDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.infoChambreDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.infoChambreDataGridView.Size = new System.Drawing.Size(538, 220);
            this.infoChambreDataGridView.TabIndex = 6;
            // 
            // infoChambreBindingSource
            // 
            this.infoChambreBindingSource.DataMember = "chambre_InfoChambre";
            this.infoChambreBindingSource.DataSource = this.chambreBindingSource;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(13, 625);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(417, 24);
            this.label4.TabIndex = 7;
            this.label4.Text = "Rapport des soins journaliers des assistants";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(775, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Soins ";
            // 
            // nbSoin
            // 
            this.nbSoin.AutoSize = true;
            this.nbSoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nbSoin.Location = new System.Drawing.Point(752, 72);
            this.nbSoin.Name = "nbSoin";
            this.nbSoin.Size = new System.Drawing.Size(17, 17);
            this.nbSoin.TabIndex = 9;
            this.nbSoin.Text = "0";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(120, 660);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker.TabIndex = 10;
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 660);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Pick a date :";
            // 
            // assistantNameDataGridView
            // 
            this.assistantNameDataGridView.AllowUserToAddRows = false;
            this.assistantNameDataGridView.AllowUserToDeleteRows = false;
            this.assistantNameDataGridView.AllowUserToResizeColumns = false;
            this.assistantNameDataGridView.AllowUserToResizeRows = false;
            this.assistantNameDataGridView.AutoGenerateColumns = false;
            this.assistantNameDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.assistantNameDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.assistantNameDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.assistantNameDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.assistantNameDataGridView.DataSource = this.assistantNameBindingSource;
            this.assistantNameDataGridView.Location = new System.Drawing.Point(18, 708);
            this.assistantNameDataGridView.Name = "assistantNameDataGridView";
            this.assistantNameDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.assistantNameDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.assistantNameDataGridView.Size = new System.Drawing.Size(242, 220);
            this.assistantNameDataGridView.TabIndex = 12;
            // 
            // infoSoinAssistantDataGridView
            // 
            this.infoSoinAssistantDataGridView.AllowUserToAddRows = false;
            this.infoSoinAssistantDataGridView.AllowUserToDeleteRows = false;
            this.infoSoinAssistantDataGridView.AllowUserToResizeColumns = false;
            this.infoSoinAssistantDataGridView.AllowUserToResizeRows = false;
            this.infoSoinAssistantDataGridView.AutoGenerateColumns = false;
            this.infoSoinAssistantDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.infoSoinAssistantDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.infoSoinAssistantDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.infoSoinAssistantDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23});
            this.infoSoinAssistantDataGridView.DataSource = this.infoSoinAssistantBindingSource;
            this.infoSoinAssistantDataGridView.Location = new System.Drawing.Point(292, 708);
            this.infoSoinAssistantDataGridView.Name = "infoSoinAssistantDataGridView";
            this.infoSoinAssistantDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.infoSoinAssistantDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.infoSoinAssistantDataGridView.Size = new System.Drawing.Size(248, 220);
            this.infoSoinAssistantDataGridView.TabIndex = 14;
            // 
            // infoSoinAssistantBindingSource
            // 
            this.infoSoinAssistantBindingSource.DataMember = "AssistantName_InfoSoinAssistant";
            this.infoSoinAssistantBindingSource.DataSource = this.assistantNameBindingSource;
            // 
            // rapportPersonneDataGridView
            // 
            this.rapportPersonneDataGridView.AllowUserToAddRows = false;
            this.rapportPersonneDataGridView.AllowUserToDeleteRows = false;
            this.rapportPersonneDataGridView.AllowUserToResizeColumns = false;
            this.rapportPersonneDataGridView.AllowUserToResizeRows = false;
            this.rapportPersonneDataGridView.AutoGenerateColumns = false;
            this.rapportPersonneDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.rapportPersonneDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rapportPersonneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rapportPersonneDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29});
            this.rapportPersonneDataGridView.DataSource = this.rapportPersonneBindingSource;
            this.rapportPersonneDataGridView.Location = new System.Drawing.Point(546, 708);
            this.rapportPersonneDataGridView.Name = "rapportPersonneDataGridView";
            this.rapportPersonneDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.rapportPersonneDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.rapportPersonneDataGridView.Size = new System.Drawing.Size(344, 220);
            this.rapportPersonneDataGridView.TabIndex = 14;
            // 
            // rapportPersonneBindingSource
            // 
            this.rapportPersonneBindingSource.DataMember = "InfoSoinAssistant_RapportPersonne";
            this.rapportPersonneBindingSource.DataSource = this.infoSoinAssistantBindingSource;
            // 
            // nbMontant
            // 
            this.nbMontant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nbMontant.Location = new System.Drawing.Point(498, 72);
            this.nbMontant.Name = "nbMontant";
            this.nbMontant.Size = new System.Drawing.Size(111, 17);
            this.nbMontant.TabIndex = 16;
            this.nbMontant.Text = "0";
            this.nbMontant.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(615, 72);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(131, 17);
            this.label8.TabIndex = 15;
            this.label8.Text = "$ Montant Totale";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "PersonName";
            this.dataGridViewTextBoxColumn27.HeaderText = "PersonName";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "noPersonne";
            this.dataGridViewTextBoxColumn24.HeaderText = "noPersonne";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.Visible = false;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "noAssistant";
            this.dataGridViewTextBoxColumn25.HeaderText = "noAssistant";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.Visible = false;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "SoinsDate";
            this.dataGridViewTextBoxColumn26.HeaderText = "SoinsDate";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.Visible = false;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "DATE";
            this.dataGridViewTextBoxColumn28.HeaderText = "DATE";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "SoinDescription";
            this.dataGridViewTextBoxColumn29.HeaderText = "SoinDescription";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // assistantNameBindingSource
            // 
            this.assistantNameBindingSource.DataMember = "AssistantName";
            this.assistantNameBindingSource.DataSource = this.b56Projet1Equipe7DataSet;
            // 
            // b56Projet1Equipe7DataSet
            // 
            this.b56Projet1Equipe7DataSet.DataSetName = "B56Projet1Equipe7DataSet";
            this.b56Projet1Equipe7DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "noPersonne";
            this.dataGridViewTextBoxColumn19.HeaderText = "noPersonne";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.Visible = false;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "noAssistant";
            this.dataGridViewTextBoxColumn20.HeaderText = "noAssistant";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.Visible = false;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "noSoin";
            this.dataGridViewTextBoxColumn21.HeaderText = "noSoin";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "description";
            this.dataGridViewTextBoxColumn22.HeaderText = "description";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "SoinsDate";
            this.dataGridViewTextBoxColumn23.HeaderText = "SoinsDate";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Visible = false;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "noAssistant";
            this.dataGridViewTextBoxColumn17.HeaderText = "noAssistant";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "AssistantName";
            this.dataGridViewTextBoxColumn18.HeaderText = "AssistantName";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "ClientName";
            this.dataGridViewTextBoxColumn12.HeaderText = "ClientName";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "ArrivalDate";
            this.dataGridViewTextBoxColumn13.HeaderText = "ArrivalDate";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "DepartureDate";
            this.dataGridViewTextBoxColumn14.HeaderText = "DepartureDate";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Occupants";
            this.dataGridViewTextBoxColumn15.HeaderText = "Occupants";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Chambre";
            this.dataGridViewTextBoxColumn16.HeaderText = "Chambre";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Visible = false;
            // 
            // chambreBindingSource
            // 
            this.chambreBindingSource.DataMember = "chambre";
            this.chambreBindingSource.DataSource = this.b56Projet1Equipe7DataSet;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "noChambre";
            this.dataGridViewTextBoxColumn8.HeaderText = "noChambre";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "emplacement";
            this.dataGridViewTextBoxColumn9.HeaderText = "emplacement";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "decorations";
            this.dataGridViewTextBoxColumn10.HeaderText = "decorations";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Visible = false;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "noTypeChambre";
            this.dataGridViewTextBoxColumn11.HeaderText = "noTypeChambre";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "description";
            this.dataGridViewTextBoxColumn3.HeaderText = "description";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "dateHeure";
            this.dataGridViewTextBoxColumn4.HeaderText = "dateHeure";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // prix
            // 
            this.prix.DataPropertyName = "prix";
            this.prix.HeaderText = "prix";
            this.prix.Name = "prix";
            this.prix.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "AssistantName";
            this.dataGridViewTextBoxColumn6.HeaderText = "AssistantName";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "noPersonne";
            this.dataGridViewTextBoxColumn7.HeaderText = "noPersonne";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Visible = false;
            // 
            // infoClientInviteBindingSource
            // 
            this.infoClientInviteBindingSource.DataMember = "InfoClientInvite";
            this.infoClientInviteBindingSource.DataSource = this.b56Projet1Equipe7DataSet;
            this.infoClientInviteBindingSource.PositionChanged += new System.EventHandler(this.infoClientInviteBindingSource_PositionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Numero";
            this.dataGridViewTextBoxColumn1.HeaderText = "Numero";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "NomPrenom";
            this.dataGridViewTextBoxColumn2.HeaderText = "NomPrenom";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // infoClientInviteTableAdapter
            // 
            this.infoClientInviteTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.assistantSoinTableAdapter = null;
            this.tableAdapterManager.assistantTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.chambreTableAdapter = null;
            this.tableAdapterManager.clientTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.inviteTableAdapter = null;
            this.tableAdapterManager.planifSoinTableAdapter = null;
            this.tableAdapterManager.reservationChambreTableAdapter = null;
            this.tableAdapterManager.soinTableAdapter = null;
            this.tableAdapterManager.typeChambreTableAdapter = null;
            this.tableAdapterManager.typeSoinTableAdapter = null;
            this.tableAdapterManager.typeUtilisateurTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Projet1.B56Projet1Equipe7DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.utilisateurTableAdapter = null;
            // 
            // infoSoinPersonneTableAdapter
            // 
            this.infoSoinPersonneTableAdapter.ClearBeforeFill = true;
            // 
            // chambreTableAdapter
            // 
            this.chambreTableAdapter.ClearBeforeFill = true;
            // 
            // infoChambreTableAdapter
            // 
            this.infoChambreTableAdapter.ClearBeforeFill = true;
            // 
            // assistantNameTableAdapter
            // 
            this.assistantNameTableAdapter.ClearBeforeFill = true;
            // 
            // infoSoinAssistantTableAdapter
            // 
            this.infoSoinAssistantTableAdapter.ClearBeforeFill = true;
            // 
            // rapportPersonneTableAdapter
            // 
            this.rapportPersonneTableAdapter.ClearBeforeFill = true;
            // 
            // Rapport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(957, 1052);
            this.Controls.Add(this.nbMontant);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rapportPersonneDataGridView);
            this.Controls.Add(this.infoSoinAssistantDataGridView);
            this.Controls.Add(this.assistantNameDataGridView);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.nbSoin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.infoChambreDataGridView);
            this.Controls.Add(this.chambreDataGridView);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.infoSoinPersonneDataGridView);
            this.Controls.Add(this.infoClientInviteDataGridView);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Rapport";
            this.Text = "Rapport";
            this.Load += new System.EventHandler(this.Rapport_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.infoClientInviteDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinPersonneDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinPersonneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoChambreDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoChambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantNameDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinAssistantDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoSoinAssistantBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportPersonneDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rapportPersonneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.assistantNameBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.b56Projet1Equipe7DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chambreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.infoClientInviteBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private B56Projet1Equipe7DataSet b56Projet1Equipe7DataSet;
        private System.Windows.Forms.BindingSource infoClientInviteBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.InfoClientInviteTableAdapter infoClientInviteTableAdapter;
        private B56Projet1Equipe7DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView infoClientInviteDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource infoSoinPersonneBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.InfoSoinPersonneTableAdapter infoSoinPersonneTableAdapter;
        private System.Windows.Forms.DataGridView infoSoinPersonneDataGridView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource chambreBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.chambreTableAdapter chambreTableAdapter;
        private System.Windows.Forms.DataGridView chambreDataGridView;
        private System.Windows.Forms.BindingSource infoChambreBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.InfoChambreTableAdapter infoChambreTableAdapter;
        private System.Windows.Forms.DataGridView infoChambreDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label nbSoin;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.BindingSource assistantNameBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.AssistantNameTableAdapter assistantNameTableAdapter;
        private System.Windows.Forms.DataGridView assistantNameDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.BindingSource infoSoinAssistantBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.InfoSoinAssistantTableAdapter infoSoinAssistantTableAdapter;
        private System.Windows.Forms.DataGridView infoSoinAssistantDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.BindingSource rapportPersonneBindingSource;
        private B56Projet1Equipe7DataSetTableAdapters.RapportPersonneTableAdapter rapportPersonneTableAdapter;
        private System.Windows.Forms.DataGridView rapportPersonneDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.Label nbMontant;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn prix;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
    }
}