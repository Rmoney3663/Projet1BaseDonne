﻿namespace Projet1
{


    public partial class B56Projet1Equipe7DataSet
    {
    }
}
